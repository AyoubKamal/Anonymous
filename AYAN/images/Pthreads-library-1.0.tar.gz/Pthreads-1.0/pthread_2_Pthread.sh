#! /bin/sh

TMP=/tmp/$$

for i in "$@" ; do
	sed "s/pthread/Pthread/g" < $i > $TMP
	cp $TMP $i
done
	rm -f $TMP
