/************************************************************************\
**  Pthread.c                                                           **
**                                                                      **
**  Copyright (c) 2002 Christophe Blaess <ccb@club-internet.fr>         **
**    ---------------------------------------------------------------   **
**                                                                      **
** This program is free software; you can redistribute it and/or modify **
** it under the terms of the GNU General Public License as published by **
** the Free Software Foundation.                                        **
**                                                                      **
**  This program is distributed in the hope that it will be useful,     **
** but WITHOUT ANY WARRANTY; without even the implied warranty of       **
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        **
** GNU General Public License for more details.                         **
**                                                                      **
** You should have received a copy of the GNU General Public License    **
** along with this program; if not, write to the Free Software          **
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA             **
** 02111-1307  USA                                                      **
**                                                                      **
**    ---------------------------------------------------------------   **
**                                                                      **
** Ce programme est libre, vous pouvez le redistribuer et/ou le modifier**
** selon les termes de la Licence Publique G�n�rale GNU publi�e par la  **
** Free Software Foundation.                                            **
**                                                                      **
** Ce programme est distribu� car potentiellement utile, mais SANS      **
** AUCUNE GARANTIE, ni explicite ni implicite, y compris les garanties  **
** de commercialisation ou d'adaptation dans un but sp�cifique.         **
** Reportez-vous � la Licence Publique G�n�rale GNU pour plus de d�tails**
**                                                                      **
** Vous devez avoir re�u une copie de la Licence Publique G�n�rale GNU  **
** en m�me temps que ce programme ; si ce n'est pas le cas, �crivez �   **
** la Free Software Foundation, Inc, 59 Temple Place, Suite 330, Boston **
** MA 02111-1307, �tats-Unis.                                           **
**                                                                      **
\************************************************************************/

	#include <errno.h>
	#include <signal.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <setjmp.h>
	#include <sys/time.h>

	#include "Pthread.h"

	/* sizeof(long)=4 bytes -> default=16kb min=2kb max=1Mb */
	#define DEFAULT_STACK_SIZE		4096
	#define MIN_STACK_SIZE			512
	#define MAX_STACK_SIZE			262144
	
	#define SCHEDULER_SIGNAL		SIGALRM
	#define SCHEDULER_TIMER			ITIMER_REAL
	#define	SCHEDULER_PERIOD_IN_USEC	10000

	typedef struct s_thread {
		Pthread_t		ident;
		int			state;
		Pthread_attr_t		attr;
		void *			ret_value;
		sigjmp_buf		context;
		long *			stack;
		void *			(*function)(void *);
		void * 			arg;
		int			thread_errno;
		struct s_thread *	waiting_thread;
		int			cancel_in_progress;
		struct s_cleanup *	cleanup;
		struct timespec		timeout;
	} thread_t;
	
	
	#define STATE_INITIALIZING	0x01
	#define STATE_RUNNING		0x02
	#define STATE_CLEANING		0x04

	#define STATE_WAITING		0x08
	#define STATE_CANCELABLE_WAIT	0x10

	#define STATE_WAITING_MASK	0x18
	#define	STATE_EXECUTING_MASK	0x1F

	#define STATE_TERMINATED	0x20
	#define STATE_FREE		0x40

	typedef struct s_cleanup {
		void			(* function) (void *);
		void *			arg;
		struct s_cleanup *	next;
	} cleanup_t;


/************************************************************************\
*                   Private functions declarations                       *
\************************************************************************/

	static void		init_library (void);

	static thread_t *	allocate_new_thread (void *(*function)(void *), void *arg);
	static void		activate_next_thread (void);

	static void		block_scheduler (void);
	static void		unblock_scheduler (void);
	static void		scheduler_signal_handler (int unused);


/************************************************************************\
*                      Private data declarations                         *
\************************************************************************/

	static int		nb_threads = 0;
	static thread_t *	threads = NULL;
	static volatile int	current_thread = -1;
	static int		next_ident = 0;
	
	
	register long *		stack_pointer __asm__("%esp");


/************************************************************************\
*                   Public functions implementations                     *
\************************************************************************/

	int
Pthread_create (Pthread_t * Pthread, Pthread_attr_t * attr, void *(*function)(void *), void *arg)
{
	thread_t * new;
	void * ret;
	if (nb_threads == 0)
		init_library ();
	if ((new = allocate_new_thread (function, arg)) == NULL)
		return (errno);
	*Pthread = new->ident;
	if (attr != NULL)
		memcpy (& (new->attr), attr, sizeof (Pthread_attr_t));
	if ((new->stack = malloc (new->attr.stack_size * sizeof (long))) == NULL) {
		new->state = STATE_FREE;
		return (errno = EAGAIN);
	}
	block_scheduler ();
	if (sigsetjmp (new->context, 1) == 0) {
		new->state = STATE_RUNNING;
		unblock_scheduler();
		return (0);
	}
	/*  here we are in the new context */
		/* On ix86 the stack grows downward */
	stack_pointer = & (threads[current_thread].stack[threads[current_thread].attr.stack_size-1]);
	unblock_scheduler ();
	ret = threads[current_thread].function (threads[current_thread].arg);
	Pthread_exit (ret);
	return (0); /* never reached, but makes compiler happy */
}


	void
Pthread_exit (void * val)
{
	block_scheduler ();
	threads[current_thread].state = STATE_CLEANING;
	threads[current_thread].cancel_in_progress = 0;
	while (threads[current_thread].cleanup != NULL) {
		unblock_scheduler ();
		Pthread_cleanup_pop (1);
		block_scheduler ();
	}
	if ((threads[current_thread].attr.flags & PTHREAD_CREATE_JOINABLE_MASK) == PTHREAD_CREATE_DETACHED)
		threads[current_thread].state = STATE_FREE;
	else
		threads[current_thread].state = STATE_TERMINATED;
	threads[current_thread].ret_value = val;
	/* if a thread is waiting for us, wake him up */
	if (threads[current_thread].waiting_thread != NULL)
		threads[current_thread].waiting_thread->state = STATE_RUNNING;
	activate_next_thread (); /* won't return */
	exit (EXIT_FAILURE); /* never reached */
}


	int
Pthread_join (Pthread_t thr, void ** ret)
{
	int	i = 0;
	int	c = current_thread;
	block_scheduler ();
	while (threads[i].ident != thr) {
		if (++ i == nb_threads) {
			unblock_scheduler ();
			return (errno=ESRCH);
		}
	}
	if (i == c) {
		unblock_scheduler ();
		return (errno=EDEADLK);
	}
	if (threads[i].waiting_thread != NULL) {
		/* another thread is already joining him */
		unblock_scheduler ();
		return (errno=EINVAL);
	}
	while ((threads[i].state & STATE_EXECUTING_MASK) != 0) {
		threads[i].waiting_thread = & (threads[c]);
		threads[c].state = STATE_CANCELABLE_WAIT;
		if (sigsetjmp (threads[c].context, 1) == 0)
			activate_next_thread ();
		Pthread_testcancel ();
	}
	if (threads[i].state != STATE_TERMINATED) {
		unblock_scheduler ();
		return (errno=EINVAL);
	}
	if (ret != NULL)
		* ret = threads[i].ret_value;
	threads[i].state = STATE_FREE;
	unblock_scheduler ();
	return (0);
}


	int
Pthread_detach (Pthread_t thr)
{
	int	i = 0;
	block_scheduler ();
	while (threads[i].ident != thr) {
		if (++i == nb_threads) {
			unblock_scheduler ();
			return (errno=ESRCH);
		}
	}
	if ((threads[i].attr.flags & PTHREAD_CREATE_JOINABLE_MASK) == PTHREAD_CREATE_DETACHED) {
		unblock_scheduler ();
		return (errno=EINVAL);
	}
	if (threads[i].waiting_thread == NULL) {
		threads[i].attr.flags &= ~ PTHREAD_CREATE_JOINABLE_MASK;
		threads[i].attr.flags |= PTHREAD_CREATE_DETACHED;
	}
	unblock_scheduler ();
	return (0);
}


	int
Pthread_equal (Pthread_t thr_1, Pthread_t thr_2)
{
	return (thr_1 == thr_2);
}


	Pthread_t
Pthread_self (void)
{
	return (threads[current_thread].ident);
}


	int
Pthread_cancel (Pthread_t thr)
{
	int	i = 0;
	block_scheduler ();
	while (threads[i].ident != thr) {
		if (++i == nb_threads) {
			unblock_scheduler ();
			return (errno=ESRCH);
		}
	}
	if ((threads[i].attr.flags & PTHREAD_CANCEL_ENABLE_MASK) == PTHREAD_CANCEL_ENABLE)
		threads[i].cancel_in_progress = 1;
	unblock_scheduler ();
	return (0);
}


	int
Pthread_setcancelstate (int state, int * previous)
{
	if ((state != PTHREAD_CANCEL_ENABLE) && (state != PTHREAD_CANCEL_DISABLE))
		return (errno=EINVAL);
	if (previous != NULL)
		*previous = threads[current_thread].attr.flags & PTHREAD_CANCEL_ENABLE_MASK;
	threads[current_thread].attr.flags &= ~ PTHREAD_CANCEL_ENABLE_MASK;
	threads[current_thread].attr.flags |= state;
	return (0);
}


	int
Pthread_setcanceltype (int type, int * previous)
{
	if ((type != PTHREAD_CANCEL_DEFERRED) && (type != PTHREAD_CANCEL_ASYNCHRONOUS))
		return (errno=EINVAL);	
	if (previous != NULL)
		*previous = threads[current_thread].attr.flags & PTHREAD_CANCEL_DEFERRED_MASK;
	threads[current_thread].attr.flags &= ~ PTHREAD_CANCEL_DEFERRED_MASK;
	threads[current_thread].attr.flags |= type;
	return (0);
}


	void
Pthread_testcancel (void)
{
	if (threads[current_thread].cancel_in_progress)
		Pthread_exit (PTHREAD_CANCELED);
}

	int
Pthread_setschedparam (Pthread_t thr, int policy, struct sched_param * param)
{
	int i, ret;
	block_scheduler ();
	while (threads[i].ident != thr) {
		if (++i == nb_threads) {
			unblock_scheduler ();
			return (errno=ESRCH);
		}
	}
	ret = Pthread_attr_setschedpolicy (& (threads[i].attr), policy);
	if (ret == 0)
		ret = Pthread_attr_setschedparam (& (threads[i].attr), param);
	unblock_scheduler();
	return (errno=ret);
}


	int
Pthread_getschedparam	(Pthread_t thr, int * policy, struct sched_param * param)
{
	int i, ret;
	block_scheduler ();
	while (threads[i].ident != thr) {
		if (++i == nb_threads) {
			unblock_scheduler ();
			return (errno=ESRCH);
		}
	}
	ret = Pthread_attr_getschedparam (& (threads[i].attr), param);
	if (ret)
		ret = Pthread_attr_getschedpolicy (& (threads[i].attr), policy);
	unblock_scheduler();
	return (ret);
}

	int
Pthread_attr_init (Pthread_attr_t * attr)
{
	if (attr == NULL)
		return (errno=EINVAL);
	attr->flags = 0;
	attr->stack_size = DEFAULT_STACK_SIZE;
	return (0);
}


	int
Pthread_attr_destroy (Pthread_attr_t * attr)
{
	errno = (attr == NULL) ? EINVAL : 0;
	return (errno);
}


	int
Pthread_attr_setdetachstate (Pthread_attr_t * attr, int state)
{
	if ((attr == NULL)
	 || ((state != PTHREAD_CREATE_JOINABLE) && (state != PTHREAD_CREATE_DETACHED)))
		return (errno=EINVAL);
	attr->flags &= ~ PTHREAD_CREATE_JOINABLE_MASK;
	attr->flags |= state;
	return (0);
}


	int
Pthread_attr_getdetachstate (Pthread_attr_t * attr, int * state)
{
	if ((attr == NULL) || (state == NULL))
		return (errno=EINVAL);
	*state = (attr->flags) & PTHREAD_CREATE_JOINABLE_MASK;
	return (0);
}

	int
Pthread_attr_setschedpolicy (Pthread_attr_t * attr, int policy)
{
	if (policy != SCHED_OTHER)
		return (errno=EPERM);
	if ((policy != SCHED_OTHER) && (policy != SCHED_RR) && (policy != SCHED_FIFO))
		return (errno=EINVAL);
	attr->sched_policy = policy;
	return (errno=0);
}

	int
Pthread_attr_getschedpolicy (Pthread_attr_t * attr, int * policy)
{
	if ((attr == NULL) || (policy == NULL))
		return (errno=EFAULT);
	* policy = attr->sched_policy;
	return (errno=0);
}

	int
Pthread_attr_setschedparam (Pthread_attr_t * attr, struct sched_param * param)
{
	if (param == NULL)
		return (errno=EFAULT);
	attr->sched_param.sched_priority = param->sched_priority;
	return (errno=0);
}

	int
Pthread_attr_getschedparam (Pthread_attr_t * attr, struct sched_param * param)
{
	if ((attr == NULL) || (param == NULL))
		return (errno=EFAULT);
	param->sched_priority = attr->sched_param.sched_priority;
	return (errno=0);
}


	int
Pthread_attr_setscope (Pthread_attr_t * attr, int scope)
{
	if ((scope != PTHREAD_SCOPE_SYSTEM) && (scope != PTHREAD_SCOPE_PROCESS))
		return (errno=EINVAL);
	if (attr == NULL)
		return (errno=EFAULT);
	if (scope != PTHREAD_SCOPE_PROCESS)
		return (ENOTSUP);
	attr -> flags &= ~ PTHREAD_SCOPE_MASK;
	attr -> flags |= scope;
	return (0);
}


	int
Pthread_attr_getscope (Pthread_attr_t * attr, int * scope)
{
	if ((attr == NULL) || (scope == NULL))
		return (errno=EFAULT);
	*scope = attr->flags & PTHREAD_SCOPE_MASK;
	return (errno=0);
}


	int
Pthread_attr_setinheritsched (Pthread_attr_t * attr, int inherit)
{
	if ((inherit != PTHREAD_INHERIT_SCHED) && (inherit != PTHREAD_EXPLICIT_SCHED))
		return (errno=EINVAL);
	if (attr == NULL)
		return (errno=EFAULT);
	attr -> flags &= ~ PTHREAD_INHERIT_MASK;
	attr -> flags |= inherit;
	return (0);
}


	int
Pthread_attr_getinheritsched (Pthread_attr_t * attr, int * inherit)
{
	if ((attr == NULL) || (inherit == NULL))
		return (errno=EFAULT);
	*inherit = attr->flags & PTHREAD_INHERIT_MASK;
	return (errno=0);
}


	int
Pthread_attr_setstacksize (Pthread_attr_t * attr, size_t size)
{
	int size_in_long = size / sizeof (long);
	if ((attr == NULL)
	 || (size_in_long < MIN_STACK_SIZE)
	 || (size_in_long > MAX_STACK_SIZE))
		return (errno=EINVAL);
	attr->stack_size = size_in_long;
	return (0);
}


	int
Pthread_attr_getstacksize (Pthread_attr_t * attr, size_t * size)
{
	if (attr == NULL)
		return (errno=EINVAL);
	return (attr->stack_size * sizeof(long));
}


	void
Pthread_cleanup_push (void (* function) (void *), void * arg)
{
	cleanup_t * clean;
	block_scheduler ();
	if ((clean = malloc (sizeof (cleanup_t))) != NULL) {
		clean -> function = function;
		clean -> arg = arg;
		clean -> next = threads[current_thread].cleanup;
		threads[current_thread].cleanup = clean;
	}
	unblock_scheduler ();
}


	void
Pthread_cleanup_pop (int execute)
{
	cleanup_t * clean;
	block_scheduler ();
	clean = threads[current_thread].cleanup;
	if (clean != NULL)
		threads[current_thread].cleanup = clean -> next;
	unblock_scheduler ();
	if (clean == NULL)
		return;
	if (execute)
		clean->function (clean->arg);
	free (clean);
}


	int
Pthread_mutex_init (Pthread_mutex_t * mutex, Pthread_mutexattr_t * attr)
{
	if (mutex == NULL)
		return (errno = EINVAL);
	block_scheduler ();
	mutex->locked = 0;
	mutex->nb_threads_waiting = 0;
	mutex->threads = NULL;
	unblock_scheduler ();
	return (errno = 0);
}


	int
Pthread_mutex_destroy (Pthread_mutex_t * mutex)
{	
	if (mutex == NULL)
		return (errno = EINVAL);
	errno = 0;
	block_scheduler ();
	if (mutex->nb_threads_waiting != 0)
		errno = EINVAL;
	unblock_scheduler ();
	return (errno);
}


	int
Pthread_mutex_lock (Pthread_mutex_t * mutex)
{
	Pthread_t * new;
	if (mutex == NULL)
		return (errno = EINVAL);
	block_scheduler ();
	if (mutex->locked) {
		new = realloc(mutex->threads, sizeof (Pthread_t) * (mutex->nb_threads_waiting + 1));
		if (new == NULL) {
			unblock_scheduler ();
			return (EAGAIN);
		}
		mutex->threads=new;
		mutex->threads[mutex->nb_threads_waiting] = current_thread;
		mutex->nb_threads_waiting ++;
		/* mutex_lock is not a cancel point */
		threads[current_thread].state = STATE_WAITING;
		if (sigsetjmp (threads[current_thread].context, 1) == 0)
			activate_next_thread ();
		
	}
	mutex->locked = 1;
	unblock_scheduler ();
	return (errno = 0);
}


	int
Pthread_mutex_unlock (Pthread_mutex_t * mutex)
{
	if ((mutex == NULL)
	 || (! mutex->locked))
		return (errno = EINVAL);
	block_scheduler ();
	if (mutex->nb_threads_waiting) {
		threads [mutex->threads[mutex->nb_threads_waiting - 1]] . state = STATE_RUNNING;
		mutex -> nb_threads_waiting --;
	}
	if (! mutex->nb_threads_waiting)
		mutex->locked = 0;
	unblock_scheduler ();
	return (0);
}


	int
Pthread_mutex_trylock (Pthread_mutex_t * mutex)
{
	if (mutex == NULL)
		return (errno = EINVAL);
	block_scheduler ();
	errno = 0;
	if (mutex->locked)
		errno = EBUSY;
	else
		mutex->locked = 1;
	unblock_scheduler ();
	return (errno);
}


	int
Pthread_mutex_timedlock (Pthread_mutex_t * mutex, struct timespec * timeout)
{
	Pthread_t * new;
	int i;
	if (mutex == NULL)
		return (errno = EINVAL);
	block_scheduler ();
	if (mutex->locked) {
		new = realloc(mutex->threads, sizeof (Pthread_t) * (mutex->nb_threads_waiting + 1));
		if (new == NULL) {
			unblock_scheduler ();
			return (EAGAIN);
		}
		mutex->threads[mutex->nb_threads_waiting] = current_thread;
		mutex->nb_threads_waiting ++;
		threads[current_thread].state = STATE_WAITING;
		threads[current_thread].timeout.tv_sec = timeout->tv_sec;
		threads[current_thread].timeout.tv_nsec = timeout->tv_nsec;
		if (sigsetjmp (threads[current_thread].context, 1) == 0)
			activate_next_thread ();
		if (threads[current_thread].timeout.tv_sec < 0) {
			/* failed */
			for (i = 0; i < mutex->nb_threads_waiting; i ++)
				if (mutex->threads[i] == current_thread)
					break;
			mutex->threads[i] = mutex->threads[mutex->nb_threads_waiting - 1];
			mutex->nb_threads_waiting --;
			unblock_scheduler();
			return (errno=ETIMEDOUT);
		}
	}
	threads[current_thread].timeout.tv_sec = 0;
	mutex->locked = 1;
	unblock_scheduler ();
	return (errno = 0);
}


	int
Pthread_mutexattr_init (Pthread_mutexattr_t * attr)
{
	errno = (attr == NULL) ? EINVAL : 0;
	return (errno);
}


	int
Pthread_mutexattr_destroy (Pthread_mutexattr_t * attr)
{
	errno = (attr == NULL) ? EINVAL : 0;
	return (errno);
}


       int
Pthread_once (Pthread_once_t  *once,  void (*func) (void))
{
	if (once == NULL)
		return (errno=EINVAL);
	if (func == NULL)
		return (errno=0);
	block_scheduler ();
	if (! *once) {
		*once = 1;
		func ();
	}
	unblock_scheduler ();
	return (0);
}


/************************************************************************\
*                   Private functions implementations                    *
\************************************************************************/

	static void
init_library (void)
{
	struct itimerval interval;
	struct sigaction action;
	if (allocate_new_thread (NULL, NULL) == NULL) {
		perror ("malloc");
		exit (EXIT_FAILURE);
	}
	current_thread = 0;
	threads[0].state = STATE_RUNNING;
	action.sa_handler = scheduler_signal_handler;
	sigemptyset (& (action.sa_mask));
	action.sa_flags = SA_RESTART;
	if (sigaction (SCHEDULER_SIGNAL, & action, NULL) != 0) {
		perror ("signal");
		exit (EXIT_FAILURE);
	}
	siginterrupt (SCHEDULER_SIGNAL, 0);
	interval.it_interval.tv_sec  = 0;
	interval.it_interval.tv_usec = SCHEDULER_PERIOD_IN_USEC;
	interval.it_value.tv_sec  = 0;
	interval.it_value.tv_usec = SCHEDULER_PERIOD_IN_USEC;
	if (setitimer (SCHEDULER_TIMER, & interval, NULL) < 0) {
		perror ("setitimer");
		exit (EXIT_FAILURE);
	}
}


	static thread_t *
allocate_new_thread (void *(*function)(void *), void *arg)
{
	int		i;
	thread_t *	new;
	block_scheduler();
	for (i = 0; i < nb_threads; i ++)
		if (threads[i].state == STATE_FREE) {
			if (threads[i].stack != NULL) {
				free (threads[i].stack);
				threads[i].stack = NULL;
			}
			break;
		}
	if (i == nb_threads) {
		new = realloc (threads, sizeof(thread_t) * (nb_threads + 1));
		if (new == NULL) {
			unblock_scheduler ();
			return (NULL);
		}
		threads = new;
		i = nb_threads;
		nb_threads ++;
	}
	threads[i].ident		= next_ident ++;
	threads[i].state		= STATE_INITIALIZING;
	threads[i].attr.flags		= 0;
	threads[i].attr.stack_size	= DEFAULT_STACK_SIZE;
	threads[i].attr.sched_param.sched_priority = 0;
	threads[i].attr.sched_policy	= SCHED_OTHER;
	threads[i].ret_value		= NULL;
	threads[i].function		= function;
	threads[i].arg			= arg;
	threads[i].thread_errno		= 0;
	threads[i].waiting_thread	= NULL;
	threads[i].cancel_in_progress	= 0;
	threads[i].cleanup		= NULL;
	threads[i].stack		= NULL;
	unblock_scheduler ();
	return (& (threads[i]));
}


	static void
block_scheduler (void)
{
	sigset_t	sigset;
	sigemptyset (& sigset);
	sigaddset   (& sigset, SCHEDULER_SIGNAL);
	sigprocmask (SIG_BLOCK, & sigset, NULL);
}


	static void
unblock_scheduler (void)
{
	sigset_t	sigset;
	sigemptyset (& sigset);
	sigaddset   (& sigset, SCHEDULER_SIGNAL);
	sigprocmask (SIG_UNBLOCK, & sigset, NULL);
}


	static void
scheduler_signal_handler (int unused)
{
	if (nb_threads == 1)
		return;
	/* we are in the thread to suspend */
	threads[current_thread].thread_errno = errno;
	if (sigsetjmp (threads[current_thread].context, 1) == 0)
		activate_next_thread ();
	/* now, we are in the task to resume */
	errno = threads[current_thread].thread_errno;
	if (threads[current_thread].cancel_in_progress)
		if ((threads[current_thread].attr.flags & PTHREAD_CANCEL_DEFERRED_MASK) == PTHREAD_CANCEL_ASYNCHRONOUS) {
			threads[current_thread].cancel_in_progress = 0;
			Pthread_exit (PTHREAD_CANCELED);
		}
}


	static void
activate_next_thread (void)
{
	int c;
	struct timeval now;
	c = current_thread;
	gettimeofday (& now, NULL);
	while (1) {
		if (++c >= nb_threads)
			c = 0;
		if (threads[c].cancel_in_progress) {
			if ((threads[c].attr.flags & PTHREAD_CANCEL_DEFERRED_MASK) == PTHREAD_CANCEL_ASYNCHRONOUS)
				break;
			if (threads[c].state == STATE_CANCELABLE_WAIT)
				break; 
		}
		if ((threads[c].state == STATE_RUNNING)
		 || (threads[c].state == STATE_CLEANING)) {
			break;
		}
		if ((threads[c].state == STATE_WAITING)
		 && (threads[c].timeout.tv_sec > 0))
			if ((threads[c].timeout.tv_sec < now.tv_sec)
			 || ((threads[c].timeout.tv_sec == now.tv_sec)
			  && (threads[c].timeout.tv_nsec >= now.tv_usec * 1000))) {
			  	threads[c].timeout.tv_sec = -1;
				break;
			}
		
		if (c == current_thread)
			/* all threads blocked or terminated */
			exit (EXIT_SUCCESS);
	}
	current_thread = c;
	siglongjmp (threads[current_thread].context, 1);
}


