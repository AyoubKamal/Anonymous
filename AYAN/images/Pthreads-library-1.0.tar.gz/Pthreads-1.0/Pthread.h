/************************************************************************\
**  Pthread.h                                                           **
**                                                                      **
**  Copyright (c) 2002 Christophe Blaess <ccb@club-internet.fr>         **
**    ---------------------------------------------------------------   **
**                                                                      **
** This program is free software; you can redistribute it and/or modify **
** it under the terms of the GNU General Public License as published by **
** the Free Software Foundation.                                        **
**                                                                      **
**  This program is distributed in the hope that it will be useful,     **
** but WITHOUT ANY WARRANTY; without even the implied warranty of       **
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        **
** GNU General Public License for more details.                         **
**                                                                      **
** You should have received a copy of the GNU General Public License    **
** along with this program; if not, write to the Free Software          **
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA             **
** 02111-1307  USA                                                      **
**                                                                      **
**    ---------------------------------------------------------------   **
**                                                                      **
** Ce programme est libre, vous pouvez le redistribuer et/ou le modifier**
** selon les termes de la Licence Publique G�n�rale GNU publi�e par la  **
** Free Software Foundation.                                            **
**                                                                      **
** Ce programme est distribu� car potentiellement utile, mais SANS      **
** AUCUNE GARANTIE, ni explicite ni implicite, y compris les garanties  **
** de commercialisation ou d'adaptation dans un but sp�cifique.         **
** Reportez-vous � la Licence Publique G�n�rale GNU pour plus de d�tails**
**                                                                      **
** Vous devez avoir re�u une copie de la Licence Publique G�n�rale GNU  **
** en m�me temps que ce programme ; si ce n'est pas le cas, �crivez �   **
** la Free Software Foundation, Inc, 59 Temple Place, Suite 330, Boston **
** MA 02111-1307, �tats-Unis.                                           **
**                                                                      **
\************************************************************************/


#ifndef P_THREAD_H
#define P_THREAD_H

#ifndef _SCHED_H
#  include <sched.h>
#endif


	typedef int 	Pthread_t;
	
	typedef struct {
		int			flags;
		int			stack_size;
		int			sched_policy;
		struct sched_param	sched_param;
	} Pthread_attr_t;

	int		Pthread_create 		(Pthread_t * Pthread, Pthread_attr_t * attr, void *(*)(void *), void *arg);
	void		Pthread_exit 		(void * val) __attribute__ ((__noreturn__));
	int		Pthread_join		(Pthread_t thr, void ** ret);
	
	#define	PTHREAD_CANCELED		(void *)-1

	int		Pthread_detach		(Pthread_t thr);
	int		Pthread_equal 		(Pthread_t thr_1, Pthread_t thr_2);
	Pthread_t	Pthread_self 		(void);

	int		Pthread_cancel		(Pthread_t thr);
	void		Pthread_testcancel	(void);
	void		Pthread_cleanup_push	(void (* function) (void *), void * arg);
	void		Pthread_cleanup_pop	(int execute);


	int		Pthread_setcancelstate	(int state, int * previous);

	#define PTHREAD_CANCEL_ENABLE		0x0000
	#define PTHREAD_CANCEL_DISABLE		0x0002
	#define PTHREAD_CANCEL_ENABLE_MASK	(PTHREAD_CANCEL_ENABLE|PTHREAD_CANCEL_DISABLE)

	int		Pthread_setcanceltype	(int type, int * previous);
	
	#define PTHREAD_CANCEL_DEFERRED		0x0000
	#define PTHREAD_CANCEL_ASYNCHRONOUS	0x0004
	#define PTHREAD_CANCEL_DEFERRED_MASK	(PTHREAD_CANCEL_DEFERRED|PTHREAD_CANCEL_ASYNCHRONOUS)

	int		Pthread_setschedparam	(Pthread_t thr, int policy, struct sched_param * param);
	int		Pthread_getschedparam	(Pthread_t thr, int * policy, struct sched_param * param);
	
	int		Pthread_attr_init 		(Pthread_attr_t * attr);
	int		Pthread_attr_destroy		(Pthread_attr_t * attr);
	int		Pthread_attr_setdetachstate	(Pthread_attr_t * attr, int state);
	int		Pthread_attr_getdetachstate	(Pthread_attr_t * attr, int * state);
	
	#define PTHREAD_CREATE_JOINABLE		0x0000
	#define PTHREAD_CREATE_DETACHED		0x0001
	#define PTHREAD_CREATE_JOINABLE_MASK	(PTHREAD_CREATE_JOINABLE|PTHREAD_CREATE_DETACHED)

	int		Pthread_attr_setschedpolicy	(Pthread_attr_t * attr, int policy);
	int		Pthread_attr_getschedpolicy	(Pthread_attr_t * attr, int * policy);
	int		Pthread_attr_setschedparam	(Pthread_attr_t * attr, struct sched_param * param);
	int		Pthread_attr_getschedparam	(Pthread_attr_t * attr, struct sched_param * param);
	int		Pthread_attr_setinheritched	(Pthread_attr_t * attr, int inherit);
	int		Pthread_attr_getinheritched	(Pthread_attr_t * attr, int * inherit);

	#define PTHREAD_EXPLICIT_SCHED		0x0000
	#define PTHREAD_INHERIT_SCHED		0x0080
	#define PTHREAD_INHERIT_MASK		(PTHREAD_EXPLICIT_SCHED | PTHREAD_INHERIT_SCHED)

	int		Pthread_attr_setscope		(Pthread_attr_t * attr, int scope);
	int		Pthread_attr_getscope		(Pthread_attr_t * attr, int * scope);

	#define PTHREAD_SCOPE_PROCESS		0x0000
	#define PTHREAD_SCOPE_SYSTEM		0x0100
	#define PTHREAD_SCOPE_MASK		(PTHREAD_SCOPE_PROCESS | PTHREAD_SCOPE_SYSTEM)

	int		Pthread_attr_setstacksize	(Pthread_attr_t * attr, size_t size);
	int		Pthread_attr_getstacksize	(Pthread_attr_t * attr, size_t * size);
	

	typedef struct {
		int		locked;
		int		nb_threads_waiting;
		Pthread_t *	threads;
	} Pthread_mutex_t;

	typedef int	Pthread_mutexattr_t;

	#define PTHREAD_MUTEX_INITIALIZER 	{0, 0, NULL}
	
	int		Pthread_mutex_init		(Pthread_mutex_t * mutex, Pthread_mutexattr_t * attr);
	int		Pthread_mutex_destroy		(Pthread_mutex_t * mutex);
	int		Pthread_mutex_lock		(Pthread_mutex_t * mutex);
	int		Pthread_mutex_unlock		(Pthread_mutex_t * mutex);
	int		Pthread_mutex_trylock		(Pthread_mutex_t * mutex);
	int		Pthread_mutex_timedlock		(Pthread_mutex_t * mutex, struct timespec * limit);
	int		Pthread_mutexattr_init		(Pthread_mutexattr_t * attr);
	int		Pthread_mutexattr_destroy	(Pthread_mutexattr_t * attr);

/* unimplemented */	int		Pthread_mutexattr_setpshared	(Pthread_mutexattr_t * attr, int pshared);
/* unimplemented */	int		Pthread_mutexattr_getpshared	(Pthread_mutexattr_t * attr, int * pshared);
/* unimplemented */	int		Pthread_mutexattr_settype	(Pthread_mutexattr_t * attr, int type);
/* unimplemented */	int		Pthread_mutexattr_gettype	(Pthread_mutexattr_t * attr, int * type);
	
	#define PTHREAD_MUTEX_DEFAULT		0x0000
	#define PTHREAD_MUTEX_RECURSIVE		0x0001
	#define PTHREAD_MUTEX_ERRORCHECK	0x0002
	#define PTHREAD_MUTEX_TYPE_MASK		(PTHREAD_MUTEX_DEFAULT | PTHREAD_MUTEX_RECURSIVE | PTHREAD_MUTEX_ERRORCHECK)

	typedef	int	Pthread_once_t;

	#define	PTHREAD_ONCE_INIT	0
 
	int		Pthread_once			(Pthread_once_t  *once,  void (*func) (void));


	typedef struct {
		int		nb_threads_waiting;
		Pthread_t *	threads;
	} Pthread_cond_t;
	
	typedef int 	Pthread_condattr_t;

	#define		PTHREAD_COND_INITIALIZER	{0, NULL}
	
/* unimplemented */	int		Pthread_cond_init		(Pthread_cond_t * cond, pthread_condattr_t * attr);
/* unimplemented */	int		Pthread_cond_destroy		(Pthread_cond_t * cond);
/* unimplemented */	int		Pthread_cond_signal		(Pthread_cond_t * cond);
/* unimplemented */	int		Pthread_cond_broadcast		(Pthread_cond_t * cond);
/* unimplemented */	int		Pthread_cond_wait		(Pthread_cond_t * cond, Pthread_mutex_t * mutex);
/* unimplemented */	int		Pthread_cond_timedwait		(Pthread_cond_t * cond, Pthread_mutex_t * mutex, struct timespec * limit);

/* unimplemented */	int		Pthread_condattr_init		(Pthread_condattr_t * attr);
/* unimplemented */	int		Pthread_condattr_destroy	(Pthread_condattr_t * attr);
/* unimplemented */	int		Pthread_condattr_setpshared	(Pthread_condattr_t * attr, int pshared);
/* unimplemented */	int		Pthread_condattr_getpshared	(Pthread_condattr_t * attr, int * pshared);

	typedef struct {
		int		state;
		int		nb_threads_waiting_r;
		Pthread_t *	threads_r;
		int		nb_threads_waiting_w;
		Pthread_t *	threads_w;
	} Pthread_rwlock_t;
	
	typedef int Pthread_rwlockattr_t;
	
	#define PTHREAD_RWLOCK_INITIALIZER	{ 0, 0, NULL, 0, NULL }
	
/* unimplemented */	int		Pthread_rwlock_init		(Pthread_rwlock_t * rwlock, Pthread_rwlockattr_t * attr);
/* unimplemented */	int		Pthread_rwlock_destroy		(Pthread_rwlock_t * rwlock);
/* unimplemented */	int		Pthread_rwlock_rdlock		(Pthread_rwlock_t * rwlock);
/* unimplemented */	int		Pthread_rwlock_tryrdlock	(Pthread_rwlock_t * rwlock);
/* unimplemented */	int		Pthread_rwlock_timedtryrdlock	(Pthread_rwlock_t * rwlock, struct timespec * limit);
/* unimplemented */	int		Pthread_rwlock_wrlock		(Pthread_rwlock_t * rwlock);
/* unimplemented */	int		Pthread_rwlock_trywrlock	(Pthread_rwlock_t * rwlock);
/* unimplemented */	int		Pthread_rwlock_timedtrywrlock	(Pthread_rwlock_t * rwlock, struct timespec * limit);
/* unimplemented */	int		Pthread_rwlock_unlock		(Pthread_rwlock_t * rwlock);

/* unimplemented */	int		Pthread_rwlockattr_init		(Pthread_rwlockattr_t * attr);
/* unimplemented */	int		Pthread_rwlockattr_destroy	(Pthread_rwlockattr_t * attr);
/* unimplemented */	int		Pthread_rwlockattr_setpshared	(Pthread_rwlockattr_t * attr, int pshared);
/* unimplemented */	int		Pthread_rwlockattr_getpshared	(Pthread_rwlockattr_t * attr, int * pshared);
	
	
	typedef int	Pthread_key_t;
	
	#define PTHREAD_KEY_INITIALIZER	0
	
/* unimplemented */	int		Pthread_key_create		(Pthread_key_t * key, void (* func) (void *));
/* unimplemented */	int		Pthread_key_delete		(Pthread_key_t key);
/* unimplemented */	int		Pthread_setspecific		(Pthread_key_t key, void * pointer);
/* unimplemented */	void *		Pthread_getspecific		(Pthread_key_t key);
	
#endif
